# Markdown Template

## Introduction
This is a sample markdown document created by Claude. Markdown is a lightweight markup language that you can use to add formatting elements to plaintext text documents.

## Formatting Basics

### Headers
# Header 1
## Header 2
### Header 3
#### Header 4
##### Header 5
###### Header 6

### Emphasis
*This text will be italic*
_This will also be italic_

**This text will be bold**
__This will also be bold__

_You **can** combine them_

### Lists

#### Unordered Lists
* Item 1
* Item 2
  * Item 2a
  * Item 2b

#### Ordered Lists
1. Item 1
2. Item 2
3. Item 3
   1. Item 3a
   2. Item 3b

### Links
[Anthropic](https://www.anthropic.com)

### Images
![Alt Text](https://example.com/image.jpg)

### Blockquotes
> This is a blockquote.
> 
> It can span multiple lines.

### Code

Inline code: `var example = true`

Code blocks:
```javascript
function helloWorld() {
  console.log("Hello, World!");
}
```

### Tables

| Header 1 | Header 2 | Header 3 |
|----------|----------|----------|
| Row 1    | Data     | Data     |
| Row 2    | Data     | Data     |
| Row 3    | Data     | Data     |

### Horizontal Rule

---

## Advanced Features

### Task Lists
- [x] Completed task
- [ ] Incomplete task
- [ ] Another task

### Footnotes
Here's a sentence with a footnote. [^1]

[^1]: This is the footnote.

### Definition Lists
Term
: Definition

Another Term
: Another definition

## Conclusion
This template demonstrates the most common markdown formatting options you can use in your documents. Feel free to modify it for your specific needs!